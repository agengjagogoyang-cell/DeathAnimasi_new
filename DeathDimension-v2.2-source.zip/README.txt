DeathDimension v2.2.0 (source, Paper 1.21.x, Java 21)

BUILD
  mvn package        -> target/DeathDimension.jar
  atau push ke GitHub: workflow .github/workflows/build.yml otomatis build (tab Actions > Artifacts)

PASANG
  1. Hapus plugins/DeathDimension.jar lama
  2. HAPUS folder plugins/DeathDimension/ (config.yml & lang.yml lama) supaya config baru terbentuk
  3. Taruh jar baru, restart server
