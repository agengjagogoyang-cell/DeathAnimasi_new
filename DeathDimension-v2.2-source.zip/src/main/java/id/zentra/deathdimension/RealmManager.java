package id.zentra.deathdimension;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadLocalRandom;

public final class RealmManager {

    private static final class Session {
        long until;
        long total;
        BossBar bar;
        Corpse corpse;
        int age;
        int slot;
        GameMode prevGm = GameMode.SURVIVAL;
        boolean leaving;
        CompletableFuture<Location> rtp;
    }

    private final DeathDimension plugin;
    private final RandomTeleporter rtp;
    private final NamespacedKey keyUntil;
    private final NamespacedKey keyGm;
    private final Map<UUID, Session> sessions = new HashMap<>();
    private final Set<UUID> pending = new HashSet<>();          // sudah mati, menunggu respawn ke realm
    private final Map<UUID, Long> protectedUntil = new HashMap<>();
    private final Set<UUID> internalTp = new HashSet<>();
    private final Set<UUID> internalGm = new HashSet<>();
    private final BukkitTask task;

    public RealmManager(DeathDimension plugin) {
        this.plugin = plugin;
        this.rtp = new RandomTeleporter(plugin);
        this.keyUntil = new NamespacedKey(plugin, "realm_until");
        this.keyGm = new NamespacedKey(plugin, "realm_gm");
        this.task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    // ------------------------------------------------------------------ status

    public boolean isInRealm(Player p) {
        return sessions.containsKey(p.getUniqueId());
    }

    public boolean isInternalTeleport(Player p) {
        return internalTp.contains(p.getUniqueId());
    }

    public boolean isInternalGameMode(Player p) {
        return internalGm.contains(p.getUniqueId());
    }

    public boolean isProtected(Player p) {
        Long t = protectedUntil.get(p.getUniqueId());
        return t != null && t > System.currentTimeMillis();
    }

    public long realmMillis() {
        return plugin.getConfig().getInt("timing.realm-seconds", 30) * 1000L;
    }

    public boolean shouldHandle(Player p) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("enabled", true)) return false;
        if (p.hasPermission("deathdimension.bypass")) return false;
        if (c.getStringList("disabled-worlds").contains(p.getWorld().getName())) return false;
        Location r = realmLocation();
        return r == null || !p.getWorld().equals(r.getWorld());
    }

    // ------------------------------------------------------------------ world realm

    public Location realmLocation() {
        FileConfiguration c = plugin.getConfig();
        World w = Bukkit.getWorld(c.getString("dimension-location.world", "realm_of_the_dead"));
        if (w == null) return null;
        return new Location(w,
                c.getDouble("dimension-location.x", 0.5),
                c.getDouble("dimension-location.y", 65.0),
                c.getDouble("dimension-location.z", 0.5),
                (float) c.getDouble("dimension-location.yaw", 0.0),
                (float) c.getDouble("dimension-location.pitch", 0.0));
    }

    public void ensureWorld() {
        FileConfiguration c = plugin.getConfig();
        String name = c.getString("dimension-location.world", "realm_of_the_dead");
        World w = Bukkit.getWorld(name);
        if (w == null && c.getBoolean("create-world-if-missing", true)) {
            w = new WorldCreator(name)
                    .environment(World.Environment.NORMAL)
                    .generator(new VoidGenerator())
                    .generateStructures(false)
                    .createWorld();
        }
        if (w == null) return;
        w.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        w.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        w.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        w.setTime(18000);
        w.setStorm(false);
        w.setThundering(false);
        Location loc = realmLocation();
        if (loc != null) w.setSpawnLocation(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
        buildPlatform(w);
    }

    private void buildPlatform(World w) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("platform.enabled", true)) return;
        Location loc = realmLocation();
        if (loc == null || !w.equals(loc.getWorld())) return;
        Material mat = Material.matchMaterial(c.getString("platform.material", "BLACK_CONCRETE"));
        if (mat == null || !mat.isBlock()) mat = Material.BLACK_CONCRETE;
        int r = Math.max(2, c.getInt("platform.radius", 4));
        int cx = loc.getBlockX(), cz = loc.getBlockZ(), y = loc.getBlockY() - 1;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > r + 0.3) continue;
                boolean edge = d > r - 1.0 && r >= 3;
                w.getBlockAt(cx + dx, y, cz + dz).setType(edge ? Material.CRYING_OBSIDIAN : mat, false);
            }
        }
    }

    /** Hapus sisa entity adegan (misal server crash saat ada pemain di realm). */
    public void cleanupLeftovers() {
        Location loc = realmLocation();
        if (loc == null) return;
        World w = loc.getWorld();
        int cx = loc.getBlockX() >> 4, cz = loc.getBlockZ() >> 4;
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) w.getChunkAt(cx + dx, cz + dz);
        for (Entity e : w.getEntities()) if (e.getScoreboardTags().contains(Corpse.TAG)) e.remove();
    }

    // ------------------------------------------------------------------ kematian (drop normal)

    public void handleDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        UUID id = p.getUniqueId();
        FileConfiguration c = plugin.getConfig();

        // mati saat sedang di realm (misal /kill): tidak ada drop, lanjut hukuman
        if (isInRealm(p)) {
            e.setKeepInventory(true);
            e.setKeepLevel(true);
            e.getDrops().clear();
            e.setDroppedExp(0);
            pending.add(id);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (p.isOnline() && p.isDead()) p.spigot().respawn();
            }, 2L);
            return;
        }

        if (!shouldHandle(p)) return;

        // INTI PERBAIKAN: walau keepInventory aktif (gamerule/plugin lain), barang & XP tetap DROP.
        if (c.getBoolean("death.drop-items", true) && e.getKeepInventory()) {
            List<ItemStack> drops = e.getDrops();
            drops.clear();
            for (ItemStack it : p.getInventory().getContents()) {
                if (it == null || it.getType().isAir()) continue;
                if (it.containsEnchantment(Enchantment.VANISHING_CURSE)) continue;
                drops.add(it.clone());
            }
            e.setKeepInventory(false);
            if (c.getBoolean("death.drop-exp", true)) {
                int lvl = p.getLevel();
                e.setKeepLevel(false);
                e.setNewLevel(0);
                e.setNewExp(0);
                e.setDroppedExp(Math.min(lvl * 7, 100));
            }
        }

        if (realmLocation() == null) return; // realm belum ada: biarkan mati normal

        int deathTicks = Math.max(5, c.getInt("timing.death-ticks", 30));
        markGm(p);
        p.getPersistentDataContainer().set(keyUntil, PersistentDataType.LONG,
                System.currentTimeMillis() + realmMillis() + deathTicks * 50L + 5000L);
        pending.add(id);

        deathEffect(p, p.getLocation().clone(), deathTicks);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && p.isDead()) p.spigot().respawn();
        }, deathTicks);
    }

    public void handleRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        if (!pending.remove(id)) return;
        Location loc = realmLocation();
        if (loc == null) return;
        e.setRespawnLocation(loc);
        Session old = sessions.get(id);
        long dur = old != null ? Math.max(3000L, old.until - System.currentTimeMillis()) : realmMillis();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) begin(p, dur);
        });
    }

    /** Animasi mati di lokasi kematian: pusaran jiwa naik, cincin gelombang, lalu ledakan + shockwave. */
    private void deathEffect(Player dead, Location at, int deathTicks) {
        World w = at.getWorld();
        FileConfiguration c = plugin.getConfig();
        sound(at, c.getString("sounds.death-start", ""));
        w.strikeLightningEffect(at);
        if (c.getBoolean("shockwave.enabled", true)) {
            shockwave(at, dead, c.getDouble("shockwave.radius", 8.0), c.getDouble("shockwave.power", 1.6));
        }
        final Particle.DustOptions dust = new Particle.DustOptions(Color.fromRGB(110, 20, 160), 1.4f);
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                t++;
                double k = t / (double) deathTicks;
                for (int i = 0; i < 2; i++) {
                    double a = t * 0.5 + i * Math.PI;
                    double r = 1.2 - 0.8 * k;
                    Location l = at.clone().add(Math.cos(a) * r, t * 0.12, Math.sin(a) * r);
                    w.spawnParticle(Particle.SOUL_FIRE_FLAME, l, 2, 0.02, 0.02, 0.02, 0.0);
                    w.spawnParticle(Particle.SOUL, l, 1, 0, 0, 0, 0.01);
                }
                double rr = k * 4.5;
                for (int i = 0; i < 20; i++) {
                    double a = i * (Math.PI * 2 / 20.0) + t * 0.1;
                    w.spawnParticle(Particle.DUST, at.clone().add(Math.cos(a) * rr, 0.15, Math.sin(a) * rr), 1, 0, 0, 0, 0, dust);
                }
                if (t >= deathTicks) {
                    Location top = at.clone().add(0, 1, 0);
                    w.spawnParticle(Particle.EXPLOSION_EMITTER, top, 1);
                    w.spawnParticle(Particle.SOUL, top, 50, 0.5, 0.8, 0.5, 0.15);
                    w.spawnParticle(Particle.SOUL_FIRE_FLAME, top, 40, 0.4, 0.6, 0.4, 0.12);
                    sound(at, c.getString("sounds.death-end", ""));
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void shockwave(Location at, Player dead, double radius, double power) {
        for (Entity ent : at.getWorld().getNearbyEntities(at, radius, radius, radius)) {
            if (!(ent instanceof LivingEntity le) || ent.equals(dead)) continue;
            if (ent instanceof Player pl && (isInRealm(pl) || pl.getGameMode() == GameMode.SPECTATOR)) continue;
            Vector v = le.getLocation().toVector().subtract(at.toVector());
            v.setY(0);
            if (v.lengthSquared() < 0.01) v = new Vector(ThreadLocalRandom.current().nextDouble(-1, 1), 0, ThreadLocalRandom.current().nextDouble(-1, 1));
            le.setVelocity(v.normalize().multiply(power).setY(0.45));
        }
    }

    // ------------------------------------------------------------------ realm

    public void begin(Player p, long millis) {
        Location base = realmLocation();
        if (base == null) {
            p.sendMessage(plugin.msg("admin-no-realm"));
            return;
        }
        UUID id = p.getUniqueId();
        markGm(p);
        Session old = sessions.remove(id);
        if (old != null) {
            old.corpse.remove();
            p.hideBossBar(old.bar);
        }

        Session s = new Session();
        s.prevGm = savedGm(p);
        s.total = millis;
        s.until = System.currentTimeMillis() + millis;
        s.slot = freeSlot();
        p.getPersistentDataContainer().set(keyUntil, PersistentDataType.LONG, s.until);

        resetBody(p);
        s.corpse = new Corpse(plugin, p, base, s.slot);
        sessions.put(id, s);

        // parkir pemain tepat di posisi/arah kamera awal, lalu spectate kamera 3 tick kemudian
        Location view = s.corpse.startView();
        internalTp.add(id);
        try {
            p.teleport(view);
        } finally {
            internalTp.remove(id);
        }
        setGm(p, GameMode.SPECTATOR);

        s.bar = BossBar.bossBar(plugin.msg("realm-bossbar", "time", String.valueOf(millis / 1000)),
                1f, BossBar.Color.PURPLE, BossBar.Overlay.NOTCHED_10);
        p.showBossBar(s.bar);
        sound(p, plugin.getConfig().getString("sounds.realm-enter", ""));
        p.sendActionBar(plugin.msg("realm-enter-actionbar"));
        if (plugin.getConfig().getBoolean("ui.show-titles", true)) {
            p.showTitle(Title.title(Component.empty(), plugin.msg("realm-enter-subtitle"),
                    Title.Times.times(Duration.ofMillis(400), Duration.ofMillis(1500), Duration.ofMillis(600))));
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> attach(p, s), 3L);
    }

    private void attach(Player p, Session s) {
        if (!p.isOnline() || sessions.get(p.getUniqueId()) != s || s.corpse.camera() == null) return;
        if (p.getGameMode() == GameMode.SPECTATOR) p.setSpectatorTarget(s.corpse.camera());
    }

    private int freeSlot() {
        for (int i = 0; ; i++) {
            boolean used = false;
            for (Session s : sessions.values()) if (s.slot == i) used = true;
            if (!used) return i;
        }
    }

    private void tick() {
        if (sessions.isEmpty() && protectedUntil.isEmpty()) return;
        long now = System.currentTimeMillis();
        protectedUntil.values().removeIf(t -> t < now);
        for (Map.Entry<UUID, Session> en : new ArrayList<>(sessions.entrySet())) {
            Player p = Bukkit.getPlayer(en.getKey());
            Session s = en.getValue();
            if (p == null || !p.isOnline() || s.leaving) continue;
            s.age++;
            s.corpse.tick(p, s.age);
            long left = s.until - now;
            if (s.age % 20 == 0) hud(p, s, left);
            if (s.age % 10 == 0 && p.getGameMode() == GameMode.SPECTATOR
                    && s.corpse.camera() != null && p.getSpectatorTarget() != s.corpse.camera()) {
                p.setSpectatorTarget(s.corpse.camera());
            }
            if (left <= 8000 && s.rtp == null) s.rtp = rtp.find();
            if (left <= 0 && (s.rtp.isDone() || left < -6000)) finish(p, s);
        }
    }

    private void hud(Player p, Session s, long left) {
        int secs = (int) Math.max(0, Math.ceil(left / 1000.0));
        float frac = (float) Math.max(0.0, Math.min(1.0, left / (double) s.total));
        s.bar.progress(frac);
        s.bar.name(plugin.msg("realm-bossbar", "time", String.valueOf(secs)));
        String color = secs <= 5 ? "<red>" : secs <= 10 ? "<yellow>" : "<green>";
        p.sendActionBar(plugin.msg("realm-actionbar", "time", String.valueOf(secs), "color", color, "bar", progressBar(frac)));
        FileConfiguration c = plugin.getConfig();
        if (secs <= 5 && secs > 0) sound(p, c.getString("sounds.realm-tick", ""));
        else if (s.age % 100 == 0) sound(p, c.getString("sounds.ambient", ""));
    }

    private String progressBar(float frac) {
        int total = 14;
        int filled = Math.round(frac * total);
        return "<#c0392b>" + "▰".repeat(filled) + "<#3a3a3a>" + "▱".repeat(total - filled);
    }

    private void finish(Player p, Session s) {
        s.leaving = true;
        Location dest = null;
        if (s.rtp != null && s.rtp.isDone() && !s.rtp.isCompletedExceptionally()) dest = s.rtp.getNow(null);
        if (dest == null) dest = rtp.fallback(rtp.targetWorld());
        final Location fd = dest;
        sound(p, plugin.getConfig().getString("sounds.death-end", ""));
        p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0, false, false, false));
        Location pc = s.corpse.startView();
        p.spawnParticle(Particle.SOUL, pc, 30, 1.0, 1.0, 1.0, 0.1);
        Bukkit.getScheduler().runTaskLater(plugin, () -> leave(p, s, fd), 12L);
    }

    private void leave(Player p, Session s, Location dest) {
        UUID id = p.getUniqueId();
        if (sessions.get(id) != s || !p.isOnline()) return;
        sessions.remove(id);
        s.corpse.remove();
        p.hideBossBar(s.bar);
        p.setSpectatorTarget(null);
        setGm(p, s.prevGm);
        clearMarks(p);
        sendOut(p, dest);
    }

    private void sendOut(Player p, Location dest) {
        UUID id = p.getUniqueId();
        protectedUntil.put(id, System.currentTimeMillis() + plugin.getConfig().getLong("post-protection-seconds", 6) * 1000L);
        internalTp.add(id);
        p.teleportAsync(dest).whenComplete((ok, err) -> Bukkit.getScheduler().runTask(plugin, () -> {
            internalTp.remove(id);
            if (!p.isOnline()) return;
            arrived(p, dest);
        }));
    }

    private void arrived(Player p, Location loc) {
        FileConfiguration c = plugin.getConfig();
        sound(p, c.getString("sounds.release", ""));
        Location up = p.getLocation().add(0, 1, 0);
        p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, up, 40, 0.4, 0.8, 0.4, 0.3);
        p.getWorld().spawnParticle(Particle.END_ROD, up, 25, 0.5, 0.9, 0.5, 0.05);
        p.sendActionBar(plugin.msg("released-actionbar",
                "x", String.valueOf(loc.getBlockX()), "y", String.valueOf(loc.getBlockY()), "z", String.valueOf(loc.getBlockZ())));
        if (c.getBoolean("ui.show-titles", true)) {
            p.showTitle(Title.title(Component.empty(), plugin.msg("released-subtitle"),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofMillis(1400), Duration.ofMillis(600))));
        }
    }

    /** Dipakai /dd release: percepat akhir hukuman (tetap lewat random teleport). */
    public boolean release(Player p) {
        Session s = sessions.get(p.getUniqueId());
        if (s == null) return false;
        s.until = System.currentTimeMillis();
        return true;
    }

    // ------------------------------------------------------------------ join / quit / shutdown

    public void handleJoin(Player p) {
        UUID id = p.getUniqueId();
        if (sessions.containsKey(id)) return;
        Long until = p.getPersistentDataContainer().get(keyUntil, PersistentDataType.LONG);
        if (until == null) return;
        long left = until - System.currentTimeMillis();
        if (left > 1500L) {
            begin(p, left); // keluar-masuk server tidak menghapus hukuman
            return;
        }
        GameMode gm = savedGm(p);
        clearMarks(p);
        setGm(p, gm);
        rtp.find().whenComplete((loc, err) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            sendOut(p, loc != null ? loc : rtp.fallback(rtp.targetWorld()));
        }));
    }

    public void handleQuit(Player p) {
        UUID id = p.getUniqueId();
        pending.remove(id);
        Session s = sessions.remove(id);
        if (s == null) return;
        s.corpse.remove();
        p.hideBossBar(s.bar);
        p.setSpectatorTarget(null);
        setGm(p, s.prevGm); // penanda waktu tetap tersimpan, jadi dilanjutkan saat join lagi
    }

    public void shutdown() {
        task.cancel();
        for (Map.Entry<UUID, Session> en : sessions.entrySet()) {
            Session s = en.getValue();
            s.corpse.remove();
            Player p = Bukkit.getPlayer(en.getKey());
            if (p != null) {
                p.hideBossBar(s.bar);
                p.setSpectatorTarget(null);
                setGm(p, s.prevGm);
            }
        }
        sessions.clear();
    }

    // ------------------------------------------------------------------ util

    private void setGm(Player p, GameMode gm) {
        UUID id = p.getUniqueId();
        internalGm.add(id);
        try {
            p.setGameMode(gm);
        } finally {
            internalGm.remove(id);
        }
    }

    private void markGm(Player p) {
        if (p.getPersistentDataContainer().has(keyGm, PersistentDataType.STRING)) return;
        GameMode g = p.getGameMode() == GameMode.SPECTATOR ? GameMode.SURVIVAL : p.getGameMode();
        p.getPersistentDataContainer().set(keyGm, PersistentDataType.STRING, g.name());
    }

    private GameMode savedGm(Player p) {
        String s = p.getPersistentDataContainer().get(keyGm, PersistentDataType.STRING);
        if (s != null) {
            try {
                GameMode g = GameMode.valueOf(s);
                return g == GameMode.SPECTATOR ? GameMode.SURVIVAL : g;
            } catch (IllegalArgumentException ignored) {
            }
        }
        return p.getGameMode() == GameMode.SPECTATOR ? GameMode.SURVIVAL : p.getGameMode();
    }

    private void clearMarks(Player p) {
        p.getPersistentDataContainer().remove(keyUntil);
        p.getPersistentDataContainer().remove(keyGm);
    }

    @SuppressWarnings("deprecation")
    private void resetBody(Player p) {
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        for (PotionEffect pe : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(pe.getType());
    }

    private void sound(Player p, String spec) {
        String[] a = parse(spec);
        if (a == null) return;
        p.playSound(p.getLocation(), a[0], SoundCategory.MASTER, Float.parseFloat(a[1]), Float.parseFloat(a[2]));
    }

    private void sound(Location at, String spec) {
        String[] a = parse(spec);
        if (a == null) return;
        at.getWorld().playSound(at, a[0], SoundCategory.MASTER, Float.parseFloat(a[1]), Float.parseFloat(a[2]));
    }

    private String[] parse(String spec) {
        if (spec == null || spec.isBlank()) return null;
        String[] a = spec.split(",");
        try {
            String key = a[0].trim();
            String vol = a.length > 1 ? a[1].trim() : "1.0";
            String pit = a.length > 2 ? a[2].trim() : "1.0";
            Float.parseFloat(vol);
            Float.parseFloat(pit);
            return new String[]{key, vol, pit};
        } catch (NumberFormatException ex) {
            return null;
        }
    }
}
