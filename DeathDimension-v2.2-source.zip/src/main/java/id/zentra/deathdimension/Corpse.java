package id.zentra.deathdimension;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;

/**
 * Adegan di realm: badan pemain terbaring DIAM, tertusuk pedang yang menancap di dada,
 * genangan darah melebar pelan, dan kamera third person yang bergerak pelan (mundur + berputar).
 */
final class Corpse {

    static final String TAG = "deathdimension_part";

    private final DeathDimension plugin;
    private final Location origin;      // permukaan platform di bawah dada mayat
    private final double worldYaw;      // rotasi mayat (radian)
    private final double baseAngle;     // sudut awal kamera
    private final List<Entity> parts = new ArrayList<>();
    private ItemDisplay camera;

    Corpse(DeathDimension plugin, Player p, Location base, int slot) {
        this.plugin = plugin;
        double ox = 0, oz = 0;
        if (slot > 0) {
            double a = (slot - 1) * (Math.PI * 2 / 5.0);
            ox = Math.cos(a) * 2.3;
            oz = Math.sin(a) * 2.3;
        }
        this.origin = new Location(base.getWorld(), base.getX() + ox, base.getY(), base.getZ() + oz);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        this.worldYaw = Math.toRadians(r.nextInt(360));
        this.baseAngle = r.nextDouble(Math.PI * 2);
        build(p);
        spawnCamera();
    }

    ItemDisplay camera() {
        return camera;
    }

    /** Posisi + arah pandang awal kamera (dipakai untuk memarkir pemain supaya transisinya mulus). */
    Location startView() {
        return camLoc(0);
    }

    // ------------------------------------------------------------------ build

    private <T extends Display> T spawn(Class<T> cls, Consumer<T> init) {
        return origin.getWorld().spawn(origin, cls, d -> {
            d.setPersistent(false);
            d.addScoreboardTag(TAG);
            d.setBrightness(new Display.Brightness(11, 11));
            init.accept(d);
        });
    }

    /** Offset lokal (badan terbaring sepanjang sumbu Z, kepala di +Z) -> offset dunia. */
    private Vector3f rot(Vector3f v) {
        return v.rotateY((float) worldYaw);
    }

    private void box(Material m, float cx, float cy, float cz, float sx, float sy, float sz, float yawDeg) {
        Vector3f c = rot(new Vector3f(cx, cy, cz));
        Quaternionf q = new Quaternionf().rotateY((float) (worldYaw + Math.toRadians(yawDeg)));
        Vector3f half = new Vector3f(sx / 2f, sy / 2f, sz / 2f);
        q.transform(half);
        Vector3f tr = new Vector3f(c).sub(half);
        Transformation t = new Transformation(tr, q, new Vector3f(sx, sy, sz), new Quaternionf());
        parts.add(spawn(BlockDisplay.class, d -> {
            d.setBlock(m.createBlockData());
            d.setTransformation(t);
        }));
    }

    private void build(Player p) {
        float headScale = (float) plugin.getConfig().getDouble("cinematic.head-scale", 1.0);
        float headRotX = (float) plugin.getConfig().getDouble("cinematic.head-rotation-x", 90.0);
        String swordName = plugin.getConfig().getString("cinematic.sword-material", "NETHERITE_SWORD");
        Material swordMat = Material.matchMaterial(swordName == null ? "" : swordName);
        if (swordMat == null) swordMat = Material.NETHERITE_SWORD;

        // badan (terbaring telentang)
        box(Material.CYAN_CONCRETE, 0f, 0.125f, 0f, 0.5f, 0.25f, 0.75f, 0f);                 // torso
        box(Material.ORANGE_TERRACOTTA, 0.48f, 0.125f, -0.02f, 0.25f, 0.25f, 0.75f, 22f);    // lengan kanan
        box(Material.ORANGE_TERRACOTTA, -0.46f, 0.125f, 0.06f, 0.25f, 0.25f, 0.75f, -14f);   // lengan kiri
        box(Material.BLUE_TERRACOTTA, 0.14f, 0.125f, -0.76f, 0.25f, 0.25f, 0.75f, 5f);       // kaki kanan
        box(Material.BLUE_TERRACOTTA, -0.14f, 0.125f, -0.75f, 0.25f, 0.25f, 0.75f, -7f);     // kaki kiri

        // kepala dengan skin pemain (muka menghadap ke atas, agak menoleh)
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        if (head.getItemMeta() instanceof SkullMeta sm) {
            sm.setOwningPlayer(p);
            head.setItemMeta(sm);
        }
        Vector3f hc = rot(new Vector3f(0.02f, 0.25f, 0.64f));
        Quaternionf hq = new Quaternionf()
                .rotateY((float) (worldYaw + Math.toRadians(18)))
                .rotateX((float) Math.toRadians(headRotX))
                .rotateY((float) Math.toRadians(180));
        parts.add(spawn(ItemDisplay.class, d -> {
            d.setItemStack(head);
            d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.HEAD);
            d.setTransformation(new Transformation(hc, hq, new Vector3f(headScale, headScale, headScale), new Quaternionf()));
        }));

        // pedang menancap tegak di dada (dua sprite menyilang supaya terlihat dari semua sisi)
        ItemStack sword = new ItemStack(swordMat);
        Vector3f sc = rot(new Vector3f(0f, 1.05f, 0.1f));
        for (int i = 0; i < 2; i++) {
            Quaternionf sq = new Quaternionf()
                    .rotateY((float) (worldYaw + Math.toRadians(90 * i)))
                    .rotateZ((float) Math.toRadians(-135));
            parts.add(spawn(ItemDisplay.class, d -> {
                d.setItemStack(sword);
                d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                d.setTransformation(new Transformation(sc, sq, new Vector3f(1.5f, 1.5f, 1.5f), new Quaternionf()));
            }));
        }

        // genangan darah yang melebar pelan
        Vector3f small = new Vector3f(0.3f, 0.02f, 0.3f);
        Vector3f big = new Vector3f(1.7f, 0.02f, 1.7f);
        Transformation t0 = new Transformation(new Vector3f(-small.x / 2f, 0.012f, -small.z / 2f), new Quaternionf(), small, new Quaternionf());
        Transformation t1 = new Transformation(new Vector3f(-big.x / 2f, 0.012f, -big.z / 2f), new Quaternionf(), big, new Quaternionf());
        BlockDisplay pool = spawn(BlockDisplay.class, d -> {
            d.setBlock(Material.RED_CONCRETE.createBlockData());
            d.setTransformation(t0);
        });
        parts.add(pool);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (pool.isValid()) {
                pool.setInterpolationDelay(0);
                pool.setInterpolationDuration(200);
                pool.setTransformation(t1);
            }
        }, 10L);
    }

    private void spawnCamera() {
        camera = origin.getWorld().spawn(camLoc(0), ItemDisplay.class, d -> {
            d.setPersistent(false);
            d.setInvulnerable(true);
            d.setGravity(false);
            d.addScoreboardTag(TAG);
        });
    }

    // ------------------------------------------------------------------ kamera

    private static double ease(double k) {
        return k * k * (3 - 2 * k);
    }

    /** Kamera third person: mulai dekat & rendah, lalu pelan-pelan mundur, naik, dan berputar. */
    private Location camLoc(int age) {
        double k = ease(Math.min(1.0, age / 160.0));
        double dist = 2.3 + 2.4 * k + Math.sin(age * 0.05) * 0.06;
        double h = 0.9 + 1.7 * k;
        double a = baseAngle + age * 0.006;
        double fx = origin.getX(), fy = origin.getY() + 0.35, fz = origin.getZ();
        double x = fx + Math.cos(a) * dist, y = fy + h, z = fz + Math.sin(a) * dist;
        double dx = fx - x, dy = fy - y, dz = fz - z;
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) Math.toDegrees(-Math.atan2(dy, Math.hypot(dx, dz)));
        return new Location(origin.getWorld(), x, y, z, yaw, pitch);
    }

    void tick(Player p, int age) {
        if (camera == null || !camera.isValid()) {
            spawnCamera();
            return;
        }
        camera.teleport(camLoc(age));
        particles(p, age);
    }

    private void particles(Player p, int age) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double ox = origin.getX(), oy = origin.getY(), oz = origin.getZ();
        if (age % 2 == 0) {
            p.spawnParticle(Particle.ASH, ox, oy + 2.5, oz, 8, 4.5, 2.5, 4.5, 0.0);
            double a = age * 0.22;
            double h = (age % 50) * 0.05;
            p.spawnParticle(Particle.SOUL_FIRE_FLAME, ox + Math.cos(a) * 0.7, oy + 0.1 + h, oz + Math.sin(a) * 0.7, 1, 0, 0, 0, 0.0);
        }
        if (age % 6 == 0) {
            p.spawnParticle(Particle.SCULK_SOUL, ox + r.nextDouble(-0.4, 0.4), oy + 0.4, oz + r.nextDouble(-0.4, 0.4), 1, 0.05, 0.05, 0.05, 0.04);
        }
        if (age % 8 == 0) {
            p.spawnParticle(Particle.DUST, ox, oy + 0.3, oz, 3, 0.35, 0.05, 0.35, 0.0,
                    new Particle.DustOptions(Color.fromRGB(140, 0, 0), 1.1f));
        }
    }

    void remove() {
        for (Entity e : parts) if (e != null && e.isValid()) e.remove();
        parts.clear();
        if (camera != null && camera.isValid()) camera.remove();
        camera = null;
    }
}
