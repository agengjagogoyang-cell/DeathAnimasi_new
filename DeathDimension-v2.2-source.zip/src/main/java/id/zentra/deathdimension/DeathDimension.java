package id.zentra.deathdimension;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class DeathDimension extends JavaPlugin implements CommandExecutor, TabCompleter {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private YamlConfiguration lang;
    private RealmManager realm;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getConfig().options().copyDefaults(true);
        saveConfig();
        loadLang();

        realm = new RealmManager(this);
        getServer().getPluginManager().registerEvents(new DeathListener(this, realm), this);

        PluginCommand cmd = getCommand("deathdimension");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }

        // World dibuat setelah server selesai start (supaya kompatibel dengan Multiverse)
        Bukkit.getScheduler().runTask(this, () -> {
            realm.ensureWorld();
            realm.cleanupLeftovers();
            for (Player p : Bukkit.getOnlinePlayers()) realm.handleJoin(p);
        });
    }

    @Override
    public void onDisable() {
        if (realm != null) realm.shutdown();
    }

    @Override
    public ChunkGenerator getDefaultWorldGenerator(String worldName, String id) {
        return new VoidGenerator();
    }

    private void loadLang() {
        File f = new File(getDataFolder(), "lang.yml");
        if (!f.exists()) saveResource("lang.yml", false);
        lang = YamlConfiguration.loadConfiguration(f);
        try (InputStream in = getResource("lang.yml")) {
            if (in != null) {
                lang.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)));
            }
        } catch (IOException ignored) {
        }
    }

    public Component msg(String key, String... kv) {
        String raw = lang.getString(key, "<red>[lang: " + key + "]");
        for (int i = 0; i + 1 < kv.length; i += 2) raw = raw.replace("{" + kv[i] + "}", kv[i + 1]);
        return MM.deserialize(raw);
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("deathdimension.admin")) {
            s.sendMessage(msg("admin-no-perm"));
            return true;
        }
        if (a.length == 0) {
            s.sendMessage(msg("admin-help"));
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                reloadConfig();
                loadLang();
                realm.ensureWorld();
                s.sendMessage(msg("admin-reloaded"));
            }
            case "setspawn" -> {
                if (!(s instanceof Player p)) {
                    s.sendMessage(msg("admin-help"));
                    return true;
                }
                Location l = p.getLocation();
                FileConfiguration cfg = getConfig();
                cfg.set("dimension-location.world", l.getWorld().getName());
                cfg.set("dimension-location.x", l.getX());
                cfg.set("dimension-location.y", l.getY());
                cfg.set("dimension-location.z", l.getZ());
                cfg.set("dimension-location.yaw", (double) l.getYaw());
                cfg.set("dimension-location.pitch", (double) l.getPitch());
                saveConfig();
                s.sendMessage(msg("admin-spawn-set"));
            }
            case "release", "send" -> {
                if (a.length < 2) {
                    s.sendMessage(msg("admin-help"));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    s.sendMessage(msg("admin-player-offline"));
                    return true;
                }
                if (a[0].equalsIgnoreCase("release")) {
                    if (realm.release(t)) s.sendMessage(msg("admin-released", "player", t.getName()));
                    else s.sendMessage(msg("admin-not-in-realm", "player", t.getName()));
                } else {
                    if (realm.realmLocation() == null) {
                        s.sendMessage(msg("admin-no-realm"));
                        return true;
                    }
                    realm.begin(t, realm.realmMillis());
                    s.sendMessage(msg("admin-sent", "player", t.getName()));
                }
            }
            default -> s.sendMessage(msg("admin-help"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("deathdimension.admin")) return out;
        if (a.length == 1) {
            for (String o : List.of("reload", "setspawn", "release", "send"))
                if (o.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(o);
        } else if (a.length == 2 && (a[0].equalsIgnoreCase("release") || a[0].equalsIgnoreCase("send"))) {
            for (Player p : Bukkit.getOnlinePlayers())
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
        }
        return out;
    }
}
