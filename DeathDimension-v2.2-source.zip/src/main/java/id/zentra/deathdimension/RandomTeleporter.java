package id.zentra.deathdimension;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.EnumSet;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

/** Teleport random buatan sendiri (tidak lewat EssentialsX /rtp). */
final class RandomTeleporter {

    private static final Set<Material> UNSAFE = EnumSet.of(
            Material.LAVA, Material.WATER, Material.FIRE, Material.SOUL_FIRE, Material.CACTUS,
            Material.MAGMA_BLOCK, Material.POWDER_SNOW, Material.SWEET_BERRY_BUSH, Material.CAMPFIRE,
            Material.SOUL_CAMPFIRE, Material.COBWEB, Material.WITHER_ROSE, Material.POINTED_DRIPSTONE);

    private final DeathDimension plugin;
    private final Random rnd = new Random();

    RandomTeleporter(DeathDimension plugin) {
        this.plugin = plugin;
    }

    boolean enabled() {
        return plugin.getConfig().getBoolean("random-teleport.enabled", true);
    }

    World targetWorld() {
        String name = plugin.getConfig().getString("random-teleport.world", "");
        World w = (name == null || name.isEmpty()) ? null : Bukkit.getWorld(name);
        return w != null ? w : Bukkit.getWorlds().get(0);
    }

    CompletableFuture<Location> find() {
        CompletableFuture<Location> f = new CompletableFuture<>();
        World w = targetWorld();
        if (!enabled() || w.getEnvironment() != World.Environment.NORMAL) {
            f.complete(fallback(w));
            return f;
        }
        attempt(w, 0, f);
        return f;
    }

    private void attempt(World w, int n, CompletableFuture<Location> f) {
        int max = plugin.getConfig().getInt("random-teleport.max-attempts", 25);
        if (n >= max) {
            f.complete(fallback(w));
            return;
        }
        int[] xz = pick(w);
        w.getChunkAtAsync(xz[0] >> 4, xz[1] >> 4, true).whenComplete((chunk, err) -> main(() -> {
            if (err != null || chunk == null) {
                attempt(w, n + 1, f);
                return;
            }
            Location l = safeAt(w, xz[0], xz[1]);
            if (l != null) f.complete(l);
            else attempt(w, n + 1, f);
        }));
    }

    private int[] pick(World w) {
        FileConfiguration c = plugin.getConfig();
        double min = c.getDouble("random-teleport.min-radius", 300);
        double max = Math.max(min + 1, c.getDouble("random-teleport.max-radius", 5000));
        double cx = c.getDouble("random-teleport.center-x", 0);
        double cz = c.getDouble("random-teleport.center-z", 0);
        for (int i = 0; i < 10; i++) {
            double a = rnd.nextDouble() * Math.PI * 2;
            double r = min + rnd.nextDouble() * (max - min);
            int x = (int) Math.floor(cx + Math.cos(a) * r);
            int z = (int) Math.floor(cz + Math.sin(a) * r);
            if (w.getWorldBorder().isInside(new Location(w, x, 64, z))) return new int[]{x, z};
        }
        return new int[]{(int) cx, (int) cz};
    }

    private Location safeAt(World w, int x, int z) {
        int y = w.getHighestBlockYAt(x, z);
        if (y <= w.getMinHeight()) return null;
        Block ground = w.getBlockAt(x, y, z);
        Material gt = ground.getType();
        if (ground.isLiquid() || !gt.isSolid() || UNSAFE.contains(gt) || Tag.LEAVES.isTagged(gt)) return null;
        if (!w.getBlockAt(x, y + 1, z).isPassable() || !w.getBlockAt(x, y + 2, z).isPassable()) return null;
        if (w.getBlockAt(x, y + 1, z).isLiquid()) return null;
        return new Location(w, x + 0.5, y + 1, z + 0.5);
    }

    Location fallback(World w) {
        if (w == null) w = Bukkit.getWorlds().get(0);
        Location s = w.getSpawnLocation();
        int y = w.getHighestBlockYAt(s.getBlockX(), s.getBlockZ());
        return new Location(w, s.getBlockX() + 0.5, y + 1, s.getBlockZ() + 0.5);
    }

    private void main(Runnable r) {
        if (Bukkit.isPrimaryThread()) r.run();
        else Bukkit.getScheduler().runTask(plugin, r);
    }
}
